public class HelloJni
{
	static
	{
		System.load("/data/data/com.termux/files/home/HelloJni.so");
	}
	public native void hello();
	public static void main(String[] args)
	{
		HelloJni hello = new HelloJni();
		hello.hello();
	}
}

