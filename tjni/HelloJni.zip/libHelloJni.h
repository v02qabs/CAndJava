#include <jni.h>

JNIEXPORT void JNICALL libHelloJni_hello(JNIEnv *env, jobject obj);
